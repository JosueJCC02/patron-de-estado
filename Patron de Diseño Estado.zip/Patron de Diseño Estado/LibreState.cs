﻿using System;

public class LibreState : IState
{
    public void Handle(Estacionamiento espacio)
    {
        Console.WriteLine($"Espacio {espacio.Id} ahora pasa de LIBRE a OCUPADO.");
        espacio.State = new OcupadoState();
    }

    public string GetNombre() => "LIBRE";
}
