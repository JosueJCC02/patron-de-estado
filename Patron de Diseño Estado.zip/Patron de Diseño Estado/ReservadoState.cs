﻿using System;

public class ReservadoState : IState
{
    public void Handle(Estacionamiento espacio)
    {
        Console.WriteLine($"Espacio {espacio.Id} ahora pasa de RESERVADO a OCUPADO.");
        espacio.State = new OcupadoState();
    }

    public string GetNombre() => "RESERVADO";
}