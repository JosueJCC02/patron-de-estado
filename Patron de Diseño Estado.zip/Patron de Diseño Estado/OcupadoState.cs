﻿using System;

public class OcupadoState : IState
{
    public void Handle(Estacionamiento espacio)
    {
        Console.WriteLine($"Espacio {espacio.Id} ahora pasa de OCUPADO a LIBRE.");
        espacio.State = new LibreState();
    }

    public string GetNombre() => "OCUPADO";
}