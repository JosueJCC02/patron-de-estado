﻿public interface IState
{
    void Handle(Estacionamiento espacio);
    string GetNombre();
}