﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("¿Cuántos espacios deseas crear?: ");
        int n = int.Parse(Console.ReadLine());

        List<Estacionamiento> espacios = new List<Estacionamiento>();

        for (int i = 1; i <= n; i++)
        {
            espacios.Add(new Estacionamiento(i, new LibreState()));
        }

        int opcion;
        do
        {
            Console.WriteLine("\n--- MENÚ ---");
            Console.WriteLine("1. Ver estados");
            Console.WriteLine("2. Cambiar estado automático");
            Console.WriteLine("3. Reservar espacio");
            Console.WriteLine("0. Salir");
            Console.Write("Opción: ");
            opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    foreach (var e in espacios)
                        e.MostrarEstado();
                    break;

                case 2:
                    Console.Write("ID del espacio: ");
                    int id = int.Parse(Console.ReadLine());
                    espacios[id - 1].SolicitarCambio();
                    break;

                case 3:
                    Console.Write("ID del espacio a reservar: ");
                    int idRes = int.Parse(Console.ReadLine());
                    espacios[idRes - 1].State = new ReservadoState();
                    Console.WriteLine($"Espacio {idRes} ahora está RESERVADO.");
                    break;
            }

        } while (opcion != 0);
    }
}