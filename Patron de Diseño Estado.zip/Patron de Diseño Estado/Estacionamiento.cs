﻿using System;

public class Estacionamiento
{
    public int Id { get; set; }
    public IState State { get; set; }

    public Estacionamiento(int id, IState state)
    {
        Id = id;
        State = state;
    }

    public void SolicitarCambio()
    {
        State.Handle(this);
    }

    public void MostrarEstado()
    {
        Console.WriteLine($"Espacio {Id}: {State.GetNombre()}");
    }
}